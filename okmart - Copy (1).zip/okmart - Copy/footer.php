<footer class="section-footer border-top padding-y">
	<div class="container">
		<p class="float-md-right"> 
			&copy Copyright 2022 <a href="index.php">OKmart.</a> 
		</p>
		<p>
			<a>Developed by</a><a href="https://github.com/SagarShinde7"> Sagar Shinde</a>
		</p>
	</div>
</footer>